package br.com.fiap.nac.dao.impl;

import javax.persistence.EntityManager;

import br.com.fiap.bean.Autor;
import br.com.fiap.nac.dao.AutorDAO;

public class AutorDAOimpl extends GenericDAOImpl<Autor, Integer> implements AutorDAO{

	public AutorDAOimpl(EntityManager em) {
		super(em);
	}
	
	

}
