package br.com.fiap.nac.dao.impl;

import javax.persistence.EntityManager;

import br.com.fiap.bean.Editora;
import br.com.fiap.nac.dao.EditoraDAO;

public class EditoraDAOimpl extends GenericDAOImpl<Editora, Integer> implements EditoraDAO{

	public EditoraDAOimpl(EntityManager em) {
		super(em);
		// TODO Auto-generated constructor stub
	}

	@Override
	public long contarPorEditora(int codigoEditora) {
		return em.createQuery("select count(l) from Livro l.editora.codigo =  :contar" , Long.class)
				.setParameter("contar", codigoEditora)
				.getSingleResult();
	}

}
