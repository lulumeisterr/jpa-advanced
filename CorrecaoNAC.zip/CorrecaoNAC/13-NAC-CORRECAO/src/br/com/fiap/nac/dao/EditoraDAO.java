package br.com.fiap.nac.dao;

import br.com.fiap.bean.Editora;

public interface EditoraDAO extends GenericDAO<Editora, Integer> {

	
	long contarPorEditora(int codigoEditora);
	
	
}
