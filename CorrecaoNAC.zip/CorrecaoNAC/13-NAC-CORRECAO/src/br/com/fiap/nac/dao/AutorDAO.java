package br.com.fiap.nac.dao;

import br.com.fiap.bean.Autor;

public interface AutorDAO extends GenericDAO<Autor, Integer> {

}
