package br.com.fiap.nac.dao;

import java.util.List;

import br.com.fiap.bean.Livro;

public interface LivroDAO extends GenericDAO<Livro, String>{

	
	// Buscar livro por titulo
	
	List<Livro> BuscarPorTitulo(String titulo);
	
	// Buscar livros por nome da editora
	
	List<Livro> buscarPorParteDoNomeEditora(String editora);
	
}
