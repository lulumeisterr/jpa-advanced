package br.com.fiap.bean;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.Lob;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Cascade;

@Entity
@Table(name = "T_NAC_LIVRO")

public class Livro {

	@Id
	@Column(name = "nr_isbn" , length = 50)
	private String isbn;
	
	@Column(name = "ds_titulo" , length = 200 , nullable = false)
	private String titiulo;
	
	@Lob
	@Column(name = "fl_capa")
	private byte[] capa;
	
	// Muitos Para um ( Muitos Livro pode ter uma editora ) 
	
	@ManyToOne(cascade = CascadeType.PERSIST)
	
	@JoinColumn(name = "cd_editora")
	private Editora editora;
	
	// Um livro pode ter muitos autores
	@ManyToMany(cascade = CascadeType.PERSIST)
	@JoinTable(name = "T_NAC_AUTOR_LIVRO" , 
	joinColumns = @JoinColumn(name="nr_isbn") , 
	inverseJoinColumns=@JoinColumn(name = "cd_autor"))
	
	private List<Autor> autores;
	
	
	
	public List<Autor> getAutores() {
		return autores;
	}

	public void setAutores(List<Autor> autores) {
		this.autores = autores;
	}

	public Editora getEditora() {
		return editora;
	}

	public void setEditora(Editora editora) {
		this.editora = editora;
	}

	public Livro() {
		
	}

	public Livro(String isbn, String titiulo, byte[] capa) {
		super();
		this.isbn = isbn;
		this.titiulo = titiulo;
		this.capa = capa;
	}

	public String getIsbn() {
		return isbn;
	}

	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}

	public String getTitiulo() {
		return titiulo;
	}

	public void setTitiulo(String titiulo) {
		this.titiulo = titiulo;
	}

	public byte[] getCapa() {
		return capa;
	}

	public void setCapa(byte[] capa) {
		this.capa = capa;
	}
	
	
	
	
	
}
