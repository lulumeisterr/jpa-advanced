package br.com.fiap.bean;

import java.util.Calendar;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "T_NAC_AUTOR")
@SequenceGenerator(name = "autor" , allocationSize = 1 ,  sequenceName = "SQ_T_NAC_AUTOR")
public class Autor {

	@Id
	@GeneratedValue(generator = "autor" , strategy = GenerationType.SEQUENCE)
	@Column(name = "CD_AUTOR")
	private int autor;
	
	@Column(name = "NM_AUTOR" , nullable = false , length = 150)
	private String nome;
	
	@Column(name = "DT_NASCIMENTO")
	private Calendar data;

	// Um autor pode ter muitos livros
	
	@ManyToMany(mappedBy = "autores")
	private List<Livro> livros;
	
	public Autor() {
		
	}
	
	
	
	
	public List<Livro> getLivros() {
		return livros;
	}




	public void setLivros(List<Livro> livros) {
		this.livros = livros;
	}




	public Autor(String nome, Calendar data) {
		super();
		this.nome = nome;
		this.data = data;
	}




	public int getAutor() {
		return autor;
	}

	public void setAutor(int autor) {
		this.autor = autor;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public Calendar getData() {
		return data;
	}

	public void setData(Calendar data) {
		this.data = data;
	}
	
	
	
	
}
