package br.com.fiap.teste;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

import br.com.fiap.bean.Autor;
import br.com.fiap.bean.Editora;
import br.com.fiap.bean.Livro;
import br.com.fiap.nac.dao.LivroDAO;
import br.com.fiap.nac.dao.impl.LivroDAOimpl;
import br.com.fiap.singleton.EntityManagerFactorySingleton;

public class TestedarAll {
	
	public static void main(String[] args) {
		
		
		EntityManagerFactory fa = EntityManagerFactorySingleton.getInstance();
			EntityManager em = fa.createEntityManager();
		
		// 1 - Cadastrar Todas as entidades
		
		Calendar dataNascimento = new GregorianCalendar(1998 , Calendar.FEBRUARY , 27);
		
		Autor a = new Autor("Lucas", dataNascimento);
		
		Editora e = new Editora("Rita Rodrigues");
		
		Livro l = new Livro("1010" , "Avar� quer raba" , null);
		
		LivroDAO Ldao = new LivroDAOimpl(em);
		
		List<Autor> listaAutores = new ArrayList<>();
		listaAutores.add(a);
		
		l.setAutores(listaAutores);
		l.setEditora(e);
		
		
		try {

			Ldao.cadastrar(l);
			Ldao.salvar();
			
		}catch(Exception ej) {
			ej.printStackTrace();
		}
		
		
		em.close();
		fa.close();
		
		
	}

}
